﻿

using System;
using System.Text;
using System.Collections.Generic;
using Extensibility;
using EnvDTE;
using EnvDTE80;

namespace UTGManagerAndExaminor
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   /// </summary>
   public static class ProjectItemExaminor
   {

      public static List<CodeClass> GetCodeClasses(FileCodeModel fileCodeModel)
      {
         List<CodeClass> lstCodeClasses = new List<CodeClass>();

         if (fileCodeModel == null || fileCodeModel.CodeElements == null || fileCodeModel.CodeElements.Count == 0)
            return lstCodeClasses;

         try
         {
            foreach (CodeElement tvCodeElementOutter in fileCodeModel.CodeElements)
            {
               if (tvCodeElementOutter is CodeNamespace)
               {
                  try
                  {
                     foreach (CodeElement tvCodeElement in ((CodeNamespace)tvCodeElementOutter).Members)
                     {
                        if (tvCodeElement != null && tvCodeElement is CodeClass)
                        {
                           lstCodeClasses.Add((CodeClass)tvCodeElement);
                        }
                     }
                  }
                  catch (Exception ex)
                  {
                     //ignore
                     UTGHelper.ErrorHandler.LogException(ex);
                  }
               }
               else if (tvCodeElementOutter is CodeClass)
               {
                  lstCodeClasses.Add((CodeClass)tvCodeElementOutter);
               }
            }
         }
         catch (Exception ex)
         {
            //ignore
            UTGHelper.ErrorHandler.LogException(ex);
         }

         return lstCodeClasses;
      }

      public static string GetUnitTestClassOriginalClassName(string unitTestClassName)
      {
         return unitTestClassName.Replace(UTGHelper.CommonStrings.DEFAULT_STRING_SEPERATOR + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX, "");
      }

      public static string GetUnitTestClassOriginalClassNamespace(string unitTestClassNamespace)
      {
         return unitTestClassNamespace.Replace(/*UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME +*/ ".UnitTests", "");
      }

   }

}
