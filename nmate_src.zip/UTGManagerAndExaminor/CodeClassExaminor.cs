﻿
using System;
using System.Text;
using Extensibility;
using EnvDTE;
using EnvDTE80;

using UTGHelper;

namespace UTGManagerAndExaminor
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   /// Uses reflection to examine the class's methodes, properties, and so on.
   /// </summary>
   public class CodeClassExaminor
   {
      private CodeClass ivCodeClass;

      protected CodeClass CodeClassElement
      {
         get { return ivCodeClass; }
         set { ivCodeClass = value; }
      }

      public CodeClassExaminor(CodeClass codeClass) {
         ivCodeClass = codeClass;
      }

      public bool HasFunctions()
      {
         if (ivCodeClass != null)
         {
            foreach (CodeElement ce in ivCodeClass.Members)
            {
               if (ce is CodeFunction || ce is CodeFunction2)
               {
                  return true;
               }
            }
         }

         return false;
      }

      public bool HasProperties()
      {
         if (ivCodeClass != null)
         {
            foreach (CodeElement ce in ivCodeClass.Members)
            {
               if (ce is CodeProperty || ce is CodeProperty2)
               {
                  return true;
               }
            }
         }

         return false;
      }

      public bool PropertiesHaveLogic()
      {
         if (HasProperties())
         {
            //Need to find a way to determine if a single property has logic other than 
            //usual set and get.
            return true;
         }

         return false;
      }
   }
}
