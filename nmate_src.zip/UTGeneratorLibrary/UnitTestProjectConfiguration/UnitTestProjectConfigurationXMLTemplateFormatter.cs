﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UTGeneratorLibrary.UnitTestProjectConfiguration
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License. 
   /// </summary>
   public static class UnitTestProjectConfigurationXMLTemplateFormatter
   {
      public static string FormateTemplate(string templateContent, string libraryPath)
      {
         if (templateContent.Equals(string.Empty))
            throw new Exception("Invalid parameter templateContent");

         if (libraryPath.Equals(string.Empty))
            throw new Exception("Invalid parameter nameSpace");

         //return string.Format(@templateContent, nameSpace, className, dateTime);
         templateContent = templateContent.Replace("{0}", libraryPath);
      
         return templateContent;
      }
   }
}
