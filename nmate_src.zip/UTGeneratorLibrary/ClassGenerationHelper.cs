﻿

using System;
using System.Collections.Generic;
using System.Text;


using Extensibility;
using EnvDTE;
using EnvDTE80;

namespace UTGeneratorLibrary
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License. 
   /// </summary>
   [Obsolete]
   public static class ClassGenerationHelper
   {
      //public static void Write(ProjectItem projectItem, string fileName)
      //{
      //   try
      //   {
      //      if (!projectItem.SaveAs(fileName))
      //         projectItem.Save(fileName);
      //   }
      //   catch (Exception)
      //   {
      //      //log it
      //      throw;
      //   }
      //}
   }
}
