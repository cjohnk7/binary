



using System;
using System.ComponentModel;
using Microsoft.Win32;

namespace UTGeneratorLibrary
{
   /// <summary>
   /// Summary description for RegistryLicenseProvider.
   /// </summary>
   public class RegistryLicenseProvider : LicenseProvider
   {
      public RegistryLicenseProvider()
      {
      }

      private bool Check()
      {
          RegistryKey licenseKey =
               Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\VisualStudio\\8.0\\Licenses\\" + this.GetType().GUID.ToString(), true);

          if (licenseKey != null)
          {
             return false;
          }

          return true;
      }

      public override License GetLicense(
      LicenseContext context,
      Type type,
      object instance,
      bool allowExceptions)
      {
         if (context.UsageMode == LicenseUsageMode.Runtime)
         {
            RegistryKey licenseKey =
               Registry.CurrentUser.OpenSubKey("Software\\UTG\\HostKeys", true);

            if (licenseKey != null)
            {
               string strLic =
                  (string)licenseKey.GetValue(type.GUID.ToString()); // reflected!

               if (strLic != null)
               {
                  string decrypted = UTGHelper.Helper.DecryptString(strLic, System.Environment.UserName + type.GUID.ToString());

                  if (decrypted.Equals(System.Environment.MachineName))
                  {
                     //return new RuntimeRegistryLicense(type);
                     return new RuntimeRegistryLicense(type);
                  }
                  else if (decrypted.Equals(System.Environment.MachineName + System.Environment.ProcessorCount.ToString()))
                  {
                     {
                        RegistryKey licenseKeyTwo =
                             Registry.CurrentUser.OpenSubKey("Software\\UTG\\SupportingKeys", true);

                        if (licenseKeyTwo != null)
                        {
                           string strLicTwo =
                              (string)licenseKeyTwo.GetValue(type.GUID.ToString()); // reflected!

                           if (strLic != null)
                           {
                              string decryptedTwo = UTGHelper.Helper.DecryptString(strLicTwo, System.Environment.UserName + type.GUID.ToString());

                              System.DateTime dateTime = DateTime.Parse(decryptedTwo);

                              System.TimeSpan timeSpan = System.DateTime.Now - dateTime;

                              if (timeSpan.Days < 30 && timeSpan.Days >= 0)
                              {
                                 RuntimeRegistryDemoLicense tvRuntimeRegistryDemoLicense = new RuntimeRegistryDemoLicense(type);
                                 tvRuntimeRegistryDemoLicense.DaysLeft = 30 - timeSpan.Days;

                                 return tvRuntimeRegistryDemoLicense;
                              }
                              else
                              {
                                 throw new LicenseException(type, instance, UTGHelper.CommonErrors.ERR_DEMO_EXPIRED);
                              }
                           }
                        }
                     }

                     
                  }
                  else
                  {
                     allowExceptions = true;
                  }
               } // if
            } // if

            if (allowExceptions == true)
            {
               throw new LicenseException(type,
                                          instance,
                                          "Your license is invalid");
            } // if
            return null;
         } // if
         else
         {
            return new DesigntimeRegistryLicense(type);
         } // else
      }
   }
}


