using System;
using System.Collections.Generic;
using System.Text;

namespace UTGeneratorLibrary
{
   public class UnitTestGeneratorException : ApplicationException
   {
   }

   public class UnitTestGenerationCountExceededException : UnitTestGeneratorException
   {
   }
}
