﻿
//#define _GENERATION_COUNTER_

using System;
using System.Collections.Generic;
using System.Text;

using Extensibility;
using EnvDTE;
using EnvDTE80;

using UTGHelper;
using UTGManagerAndExaminor;

namespace UTGeneratorLibrary
{
   public partial class UnitTestGenerator
   {
#if _GENERATION_COUNTER_
      internal static int _generationClass = 0;
      internal static int _generationMemeber = 0;
      internal static int _generationClassMax = 5;
      internal static int _generationMemeberMax = 25;
#endif


#if _GENERATION_COUNTER_
      public static int OneTry
      {
         get { return _generationMemeber; }

         set{_generationMemeber++;}
      }


      public static int MaxTry
      {
         get { return _generationMemeberMax / _generationClassMax; } 
      }
#endif

      /// <summary>
      /// This source is under the New BSD License
      /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
      /// Only public method to be called on the Generation Library. 
      /// </summary>
      /// <param name="ce">CodeClass, CodeFuntion are only types supported right now</param>
      /// <param name="applicationObject"></param>
      public static void GenerateUnitTestForCodeElement(CodeElement ce, ref DTE2 applicationObject, UnitTestCodeType codeType, System.ComponentModel.License license)
      {
         if (ce == null)
         {
            throw new Exception("Invalid parameter CodeElement");
         }

         if (license is RuntimeRegistryDemoLicense)
         {
            if (ce is CodeClass)
            {
#if _GENERATION_COUNTER_
               if (_generationClass > _generationClassMax)
               {
                  throw new UnitTestGenerationCountExceededException();
               }
               else
                  _generationClass++;
#endif
            }
            else if (ce is CodeFunction || ce is CodeProperty)
            {
#if _GENERATION_COUNTER_
               if (_generationMemeber >= _generationMemeberMax)
                  throw new UnitTestGenerationCountExceededException();
               else
                  _generationMemeber++;
#endif
            }
         }


         CodeSelectionHandler.OnCodeElementSelection(ce, ref applicationObject, codeType/*, license*/);
      }

      public static void GenerateUnitTestForCodeElement(Project project, ref DTE2 applicationObject, UnitTestCodeType codeType, System.ComponentModel.License license)
      {
         if (project == null)
         {
            throw new Exception("Invalid projectItem CodeElement");
         }

         if (license is RuntimeRegistryDemoLicense)
         {
            throw new UnitTestGenerationCountExceededException();
         }

         CodeSelectionHandler.OnCodeElementSelection(project, ref applicationObject, codeType/*, license*/);
      }

      internal static Project CreateAndAddUnitTestProject(Solution2 sol, string csProjectName, string csProjectPath, UnitTestCodeType codeType /*, System.ComponentModel.License license*/)
      {
         //System.Windows.Forms.MessageBox.Show("You must have at least 1 project in your current solution with a project name that ends with UnitTest");
         Project proj = null;

         try
         {
            String csItemTemplatePath;

            switch(codeType)
            {
               case UnitTestCodeType.CSharp:
                  csItemTemplatePath = sol.GetProjectTemplate(UTGHelper.CommonStrings.DEFAULT_PROJECT_TEMPLATE, UTGHelper.CommonStrings.DEFAULT_LANGUAGE);
                  break;
               case UnitTestCodeType.VB:
                  csItemTemplatePath = sol.GetProjectTemplate(UTGHelper.CommonStrings.DEFAULT_PROJECT_TEMPLATE, UTGHelper.CommonStrings.DEFAULT_VB_LANGUAGE);
                  break;
               default:
                  throw new Exception(string.Format(UTGHelper.CommonErrors.ERR_LANUAGE_TYPE_NOT_SUPPORTED, codeType.ToString()));
            }

            proj = sol.AddFromTemplate(csItemTemplatePath, csProjectPath, csProjectName, false);
         }
         catch (Exception ex)
         {
            ErrorHandler.LogException(ex);

            throw;

            //UTGHelper.ErrorHandler.HandleException(ex);
         }

         return proj;
      }


      /// <summary>
      /// 
      /// </summary>
      /// <param name="applicationObject"></param>
      /// <param name="project"></param>
      /// <param name="className">Whatever name you wish to give your class should you pass a null for classContent parameter</param>
      /// <param name="classContent">passing a string.Empty will add an empty class</param>
      /// <returns></returns>
      internal static ProjectItem AddClassToProject(ref DTE2 applicationObject, ref Project project, string className, string classFullPath/*, System.ComponentModel.License license*/)
      {
         ProjectItem projectItem = null;

         //Are we addding a pre-exiting class, or creating an empty one?
         if (classFullPath != string.Empty)
         {
            projectItem =
               ProjectManager.AddClassToProject((Solution2)applicationObject.Solution, project, classFullPath);
         }
         else
         {
            projectItem =
               ProjectManager.AddClassToProject((Solution2)applicationObject.Solution, project, className, UTGHelper.CommonStrings.DEFAULT_CODE_FILE_EXTENSION);
         }

         return projectItem;
      }


      /// <summary>
      /// New
      /// </summary>
      /// <param name="applicationObject"></param>
      /// <returns></returns>
      internal static string GetUnitTestProjectPath(string projectBeingTestedName, ref DTE2 applicationObject)
      {
         Project unitTestProject = ProjectExaminar.GetUnitTestProject(projectBeingTestedName, applicationObject);

         if (unitTestProject != null)
            return UTGHelper.FileInputOutput.GetFilePath(unitTestProject.FullName);

         Project parentProject =
            applicationObject.ActiveWindow.Document.ProjectItem.ContainingProject;

         return UTGHelper.FileInputOutput.GetFilePath(parentProject.FullName);

      }

   }
}
