﻿//#define _USE_TEMPLATES_

using System;
using System.Collections.Generic;
using System.Text;

using Extensibility;
using EnvDTE;
using EnvDTE80;

using UTGManagerAndExaminor;
using UTGHelper;

namespace UTGeneratorLibrary
{
   
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   ///Test-driven development in a five-step nutshell is as follows:
   ///Decide what you want to code 
   ///Write some tests which your code must pass 
   ///Check the test fails initially by running it without writing the code 
   ///Write the smallest amount of code possible for the test to pass. Refactor your code as required. 
   ///Repeat steps 2 to 4 until the code you have written does everything you want it to do 
   /// </summary>
   public partial class UnitTestGenerator
   {



      //<Test()> _

      static private string TEMP_TEMPLATE_VB_CONTENT =
@"
Imports nunit.Framework
Imports NUnit.Framework.SyntaxHelpers

'{1000} generated Unit Test File for {0}.{1}.
'File generated on {2}.
'DO NOT CHANGE CLASS NAME

<TestFixture()> _ 
Public Class {1}_NUnit

   Dim iv{1}Type As {1}

   <NUnit.Framework.SetUp()> _
   Sub Init()
      iv{1}Type = New {1}()
   End Sub

   <NUnit.Framework.TearDown()> _
   Sub Clean()
      iv{1}Type = Nothing
   End Sub

      
   {3}

End Class

";

      static private string TMEP_TEMPLATE_CONTENT =
@"
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace {0}.UnitTests
{

   ///<summary>
   ///{1000} generated Unit Test File for {0}.{1}.
   ///File generated on {2}.
   ///Note: Keep fixture’s full qualifying names if you wish to integrate this test with other testing tools.
   ///</summary>

   //DO NOT CHANGE THIS CLASS' NAME
   [NUnit.Framework.TestFixture()]
   public partial class {1}_NUnit
   {
      private {1} iv{1}Type;

      [NUnit.Framework.SetUp()]
      public void Init()
      {
         //
         // TODO: Code to run at the start of every test case
         //

         iv{1}Type = new {1}();
      }


      [NUnit.Framework.TearDown()]
      public void Clean()
      {
         //
         // TODO: Code that will be called after each Test case
         //

         iv{1}Type = null;
      }

      {3}
   }
}
";



      /// <summary>
      /// Generates a Unit Test for a Class
      /// </summary>
      /// <param name="codeFuntion">Class's Code Function</param>
      /// <returns>A string representation for the Class's Unit Test</returns>
      public static string GenerateTestShell(CodeClass codeClass, UnitTestCodeType codeType)
      {
         string unitTestString = string.Empty;

         string nClassUniteTestTemplateContent = string.Empty;

#if _USE_TEMPLATES_

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               nClassUniteTestTemplateContent = FileInputOutput.GetCSharpUnitTestTemplateFileContent();
               break;
            case UnitTestCodeType.VB:
               nClassUniteTestTemplateContent = FileInputOutput.GetVisualBasicUnitTestTemplateFileContent();
               break;
            default:
               break;
         }
#else
         switch(codeType)
         {
            case UnitTestCodeType.CSharp:
               nClassUniteTestTemplateContent = TMEP_TEMPLATE_CONTENT;
            break;
            case UnitTestCodeType.VB:
               nClassUniteTestTemplateContent = TEMP_TEMPLATE_VB_CONTENT;
               break;
            default:
               break;
         }
#endif

         string tvNamespace = string.Empty;

         if (codeClass.Namespace != null)
            tvNamespace = codeClass.Namespace.FullName;
         else
            tvNamespace = ProjectExaminar.GetProjectOutputAssemblyNameExtensionless(ProjectExaminar.GetCodeClassParentProject(codeClass));

         if (codeClass.IsAbstract || ((CodeClass2)codeClass).IsShared)
         {
            unitTestString = UnitTestTemplateFormatter.nClassUnitTestTemplateFormater.FormateTemplateForShared(
             @nClassUniteTestTemplateContent,
             tvNamespace,
             codeClass.Name,
             System.DateTime.Now.ToString());

         }
         else
         {
            unitTestString = UnitTestTemplateFormatter.nClassUnitTestTemplateFormater.FormateTemplate(
              @nClassUniteTestTemplateContent,
              tvNamespace,
              codeClass.Name,
              System.DateTime.Now.ToString());
         }

         unitTestString = unitTestString.Replace("{2}", "");
         unitTestString = unitTestString.Replace("{3}", "");

         return unitTestString;
      }



      /// <summary>
      /// Generates a Unit Test for a Class
      /// </summary>
      /// <param name="unitTestCodeClass">Unit Test Class's Code Function. A shell will suffice</param>
      /// <param name="codeFuntion">Class's Code Function</param>
      /// <returns>A string representation for the Class's Unit Test</returns>
      public static CodeClass GenerateTest(CodeClass unitTestCodeClass, CodeClass originalCodeClass , UnitTestCodeType codeType)
      {
         string unitTestString = string.Empty;

         unitTestCodeClass.Comment = originalCodeClass.Comment;

         unitTestCodeClass.DocComment = originalCodeClass.DocComment;

         foreach (CodeElement ce in originalCodeClass.Members)
         {
            if ( ce is CodeFunction && ((CodeFunction)ce).Access == vsCMAccess.vsCMAccessPublic)
            {
               CodeFunction newUnitTestCodeFunction = GenerateTest(unitTestCodeClass, (CodeFunction)ce, codeType);
            }
            else if (ce is CodeProperty && ((CodeProperty)ce).Access == vsCMAccess.vsCMAccessPublic)
            {
               CodeFunction newUnitTestCodeFunction = GenerateTest(unitTestCodeClass, (CodeProperty)ce, codeType);
            }
         }
  
         return unitTestCodeClass;
      }


      /// <summary>
      /// Generates a Unit Test for a Class
      /// </summary>
      /// <param name="unitTestCodeClass">Unit Test Class's Code Function. A shell will suffice</param>
      /// <param name="codeElement">Class's Code Function or Code Property</param>
      /// <param name="originalCodeClass">The class from which we have chosen our codeElement</param>
      /// <returns>A CodeClass representation the newly generated class</returns>
      public static CodeClass GenerateTest(CodeClass unitTestCodeClass, CodeClass originalCodeClass, CodeElement codeElement, UnitTestCodeType codeType)
      {
         if (codeElement is CodeFunction || codeElement is CodeProperty)
         {
            string unitTestString = string.Empty;

            unitTestCodeClass.Comment = originalCodeClass.Comment;

            unitTestCodeClass.DocComment = originalCodeClass.DocComment;

            foreach (CodeElement ce in originalCodeClass.Members)
            {
               if (ce == codeElement)
               {
                  if (ce is CodeFunction && ((CodeFunction)ce).Access == vsCMAccess.vsCMAccessPublic)
                     GenerateTest(unitTestCodeClass, (CodeFunction)ce, codeType);
                  else if (ce is CodeProperty && ((CodeProperty)ce).Access == vsCMAccess.vsCMAccessPublic)
                     GenerateTest(unitTestCodeClass, (CodeProperty)ce, codeType);
               }
            }

            return unitTestCodeClass;
         }
         else
            throw new Exception(string.Format(UTGHelper.CommonErrors.ERR_TYPE_NOT_SUPPORTED, codeElement.GetType().ToString()));
      }

      public static string GetNextAvailableCopyName(CodeClass codeClass, ref string codeFunctionName)
      {
         return GetNextAvailableCopyName(codeClass, ref codeFunctionName);
      }

      public static string GetNextAvailableCopyName(CodeClass codeClass, ref string codeFunctionName, Project project)
      {
         codeFunctionName = "CopyOf" + codeFunctionName;

          if (!CodeSelectionHandler.CanGenerateHandleCodeFunction(
            codeClass,
            codeFunctionName))
         {
            return GetNextAvailableCopyName(codeClass, ref codeFunctionName, project);
         }

         return codeFunctionName;
      }

      public static CodeFunction GenerateTest(CodeClass unitTestCodeClass, CodeFunction originalClassCodeFuntion, UnitTestCodeType codeType)
      {
         vsCMFunction functionKind = vsCMFunction.vsCMFunctionFunction;
         object functionType = null;

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               functionKind = vsCMFunction.vsCMFunctionFunction;
               functionType = vsCMTypeRef.vsCMTypeRefVoid;
               break;
            case UnitTestCodeType.VB:
               functionKind = vsCMFunction.vsCMFunctionSub;
               functionType = vsCMTypeRef.vsCMTypeRefVoid;
               break;
            default:
               break;
         }

         string nextAvailableName = originalClassCodeFuntion.Name;

         if (!CodeSelectionHandler.CanGenerateHandleCodeFunction(unitTestCodeClass,
            nextAvailableName))
         {
            nextAvailableName = GetNextAvailableCopyName(unitTestCodeClass, ref nextAvailableName, ProjectExaminar.GetCodeClassParentProject(unitTestCodeClass));
         }

         CodeFunction unitTestCodeFunction = unitTestCodeClass.AddFunction(
            nextAvailableName,
            functionKind,
            functionType,
            /*originalClassCodeFuntion.Type,*/
            -1,
            originalClassCodeFuntion.Access,
            -1);

         bool tvIsStatic = originalClassCodeFuntion.IsShared;

         //unitTestCodeFunction.IsShared = originalClassCodeFuntion.IsShared;

         //add the nunit attribute to the function
         unitTestCodeFunction.AddAttribute("NUnit.Framework.Test", "", -1);


         try
         {
            unitTestCodeFunction.Comment = originalClassCodeFuntion.Comment;

            unitTestCodeFunction.DocComment = originalClassCodeFuntion.DocComment;
         }
         catch (Exception ex)
         {//ignore, for some resoan the doc throws in vb
            ErrorHandler.LogException(ex);
         }

         //Stop here for now...

         //if (codeType == UnitTestCodeType.VB)
         //   return unitTestCodeFunction;

         string tvFunctionCallTemplate = string.Empty; //"iv{0}Type.{1}(";
         string tvFunctionReturnTemplate = string.Empty; //"{0} iv{1}Return = ";

         if (tvIsStatic)
         {
            tvFunctionCallTemplate = "{0}.{1}(";
         }
         else
         {
            tvFunctionCallTemplate = "iv{0}Type.{1}(";
         }
         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               //tvFunctionCallTemplate = "iv{0}Type.{1}(";
               //if(!tvIsStatic)
                  tvFunctionReturnTemplate = "{0} iv{1}Return = ";
               break;
            case UnitTestCodeType.VB:
               //tvFunctionCallTemplate = "iv{0}Type.{1}(";
               //if (!tvIsStatic)
                  tvFunctionReturnTemplate = "Dim iv{1}Return As {0} = ";
               break;
            default:
               break;
         }

         string tvTempParameterList = string.Empty;
         string tvFunctionCall = tvFunctionCallTemplate;
         string tvFunctionReturn = tvFunctionReturnTemplate;


         if (!originalClassCodeFuntion.FunctionKind.ToString().Equals("vsCMFunctionConstructor"))
         {
            CodeElements tvParameters = originalClassCodeFuntion.Parameters;

            foreach (CodeElement tvCodeElement in tvParameters)
            {
               if (!tvFunctionCall.Equals(tvFunctionCallTemplate))
               {
                  tvFunctionCall += ", ";
               }

               CodeParameter2 tvCodeParameter = (CodeParameter2)tvCodeElement;

               string parameterName = tvCodeParameter.Name;

               CodeTypeRef tvParameterType = tvCodeParameter.Type;

               vsCMParameterKind tvParameterKind = tvCodeParameter.ParameterKind;

               

               string parameterTypeAsString = tvParameterType.AsString;
         
               switch (codeType)
               {
                  case UnitTestCodeType.CSharp:
                       tvTempParameterList += parameterTypeAsString + " " + parameterName + " = default(" + parameterTypeAsString + ");" + Environment.NewLine + StringHelper.GetTabString();
                     break;
                  case UnitTestCodeType.VB:
                     tvTempParameterList += "Dim " + parameterName + " As " + parameterTypeAsString + " = New " + parameterTypeAsString + "()" + Environment.NewLine + StringHelper.GetTabString();
                     break;
                  default:
                     break;
               }

               if (tvParameterKind == vsCMParameterKind.vsCMParameterKindRef)
               {
                  if (codeType == UnitTestCodeType.CSharp)
                     tvFunctionCall += "ref " + parameterName;
                  else if (codeType == UnitTestCodeType.VB)
                     tvFunctionCall += parameterName;
               }
               else if (tvParameterKind == vsCMParameterKind.vsCMParameterKindOut)
               {
                  if (codeType == UnitTestCodeType.CSharp)
                     tvFunctionCall += "out " + parameterName;
                  else if (codeType == UnitTestCodeType.VB)
                     tvFunctionCall += parameterName;
               }
               else if (tvParameterKind == vsCMParameterKind.vsCMParameterKindIn)
               {
                  if (codeType == UnitTestCodeType.CSharp)
                     tvFunctionCall += "in " + parameterName;
                  else if (codeType == UnitTestCodeType.VB)
                     tvFunctionCall += parameterName;
               }
               else
               {
                  tvFunctionCall += parameterName;
               }
            }
   
            switch (codeType)
            {
               case UnitTestCodeType.CSharp:
                    tvFunctionCall = string.Format(tvFunctionCall + ");" + Environment.NewLine, ((CodeClass)originalClassCodeFuntion.Parent).Name, originalClassCodeFuntion.Name);
                  break;
               case UnitTestCodeType.VB:
                  tvFunctionCall = string.Format(tvFunctionCall + ")" + Environment.NewLine, ((CodeClass)originalClassCodeFuntion.Parent).Name, originalClassCodeFuntion.Name);
                  break;
               default:
                  break;
            }
         }

         if (originalClassCodeFuntion.Type.TypeKind != vsCMTypeRef.vsCMTypeRefVoid)
         {
            tvFunctionReturn = string.Format(tvFunctionReturn, originalClassCodeFuntion.Type.AsString, originalClassCodeFuntion.Name);
            tvFunctionCall = tvFunctionReturn + tvFunctionCall;
         }

         TextPoint bodyStartingPoint =
            unitTestCodeFunction.GetStartPoint(vsCMPart.vsCMPartBody);

         EditPoint boydEditPoint = bodyStartingPoint.CreateEditPoint();

         if (!originalClassCodeFuntion.FunctionKind.ToString().Equals("vsCMFunctionConstructor"))
         {
            if (codeType == UnitTestCodeType.CSharp)
            {
                boydEditPoint.Insert("\t\t\t// TODO: Update variable/s' defaults to meet test needs" + Environment.NewLine);
               
            }
            else if (codeType == UnitTestCodeType.VB)
            {
                boydEditPoint.Insert("\t\t\t' TODO: Update variable/s' defaults to meet test needs" + Environment.NewLine);
            }

            //else if (codeType == UnitTestCodeType.VB)
            //   boydEditPoint.Insert("\t\t\t'Update the defaults here to meet your testing needs\r\n");

            boydEditPoint.Insert(StringHelper.GetTabString() + tvTempParameterList + Environment.NewLine);


            boydEditPoint.Insert(StringHelper.GetTabString() + tvFunctionCall + Environment.NewLine);
         }

         if (originalClassCodeFuntion.Type.TypeKind != vsCMTypeRef.vsCMTypeRefVoid)
         {
            string stringHolder = "iv{0}Return";
            stringHolder = string.Format(stringHolder, originalClassCodeFuntion.Name);
            //FIX ME (tabing)
             //boydEditPoint.Insert(string.Format("\t\t\tAssert.AreEqual({0}, default({1}));\r\n", stringHolder, originalClassCodeFuntion.Type.AsString));
         }

         
         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
                 boydEditPoint.Insert(Environment.NewLine);
                
                 boydEditPoint.Insert("\t\t\t//TODO: Update Assert to meet test needs" + Environment.NewLine);
                
                 boydEditPoint.Insert("\t\t\t//Assert.AreEqual( , );" + Environment.NewLine);

                 boydEditPoint.Insert("\t\t\t" + Environment.NewLine);
                 
                 boydEditPoint.Insert("\t\t\tthrow new Exception(\"Not Implemented\");" + Environment.NewLine);
               break;
            case UnitTestCodeType.VB:
               boydEditPoint.Insert(Environment.NewLine);
               
               boydEditPoint.Insert("\t\t\t'TODO: Update Assert to meet test needs" + Environment.NewLine);

               boydEditPoint.Insert("\t\t\t'Assert.AreEqual( , )" + Environment.NewLine);

               boydEditPoint.Insert("\t\t\t" + Environment.NewLine);
               
               boydEditPoint.Insert("\t\t\tThrow New Exception 'Not Implemented'" + Environment.NewLine);
               break;
            default:
               break;
         }

         return unitTestCodeFunction;
      }

   
      public static CodeFunction GenerateTest(CodeClass unitTestCodeClass, CodeProperty originalClassCodeProperty, UnitTestCodeType codeType)
      {
         vsCMFunction functionKind = vsCMFunction.vsCMFunctionFunction;
         object functionType = null;

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               functionKind = vsCMFunction.vsCMFunctionFunction;
               functionType = vsCMTypeRef.vsCMTypeRefVoid;
               break;
            case UnitTestCodeType.VB:
               functionKind = vsCMFunction.vsCMFunctionSub;
               functionType = vsCMTypeRef.vsCMTypeRefVoid;
               break;
            default:
               break;
         }


         string nextAvailableName = originalClassCodeProperty.Name;

         if (!CodeSelectionHandler.CanGenerateHandleCodeFunction(unitTestCodeClass,
            nextAvailableName))
         {
            nextAvailableName = GetNextAvailableCopyName(unitTestCodeClass, ref nextAvailableName, ProjectExaminar.GetCodeClassParentProject(unitTestCodeClass));
         }

         CodeFunction unitTestCodeFunction = unitTestCodeClass.AddFunction(
            nextAvailableName,
            functionKind,
            functionType,
            /*originalClassCodeFuntion.Type,*/
            -1,
            originalClassCodeProperty.Access,
            -1);

         unitTestCodeFunction.AddAttribute("NUnit.Framework.Test", "", -1);

         try
         {
            unitTestCodeFunction.Comment = originalClassCodeProperty.Comment;

            unitTestCodeFunction.DocComment = originalClassCodeProperty.DocComment;
         }
         catch (Exception ex)
         {
            ErrorHandler.LogException(ex);
            //ignore
         }

         TextPoint bodyStartingPoint =
               unitTestCodeFunction.GetStartPoint(vsCMPart.vsCMPartBody);

         EditPoint boydEditPoint = bodyStartingPoint.CreateEditPoint();

         //Stop here if not read-write type property now...

         if (originalClassCodeProperty.Setter == null)
         {
            
            boydEditPoint = bodyStartingPoint.CreateEditPoint();

            //FIX ME (tabing)
              switch (codeType)
              { 
                 case UnitTestCodeType.CSharp:
                      boydEditPoint.Insert(StringHelper.GetTabString() + "// Property is not read-write please add your own code here." + Environment.NewLine);
                     break; 
                 case UnitTestCodeType.VB:
                     boydEditPoint.Insert(StringHelper.GetTabString() + "' Property is not read-write please add your own code here." + Environment.NewLine);
                     break; 
                 default:
                  break;
               }
            return unitTestCodeFunction;
         }
 

         string tvFunctionCallTemplate = string.Empty; // "iv{0}Type.{1} = default({2});";

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
                 tvFunctionCallTemplate = "iv{0}Type.{1} = default({2});" + Environment.NewLine;
               break;
            case UnitTestCodeType.VB:
               tvFunctionCallTemplate = "iv{0}Type.{1} = New {2}()" + Environment.NewLine;
               break;
            default:
               break;
         }


         string tvFunctionCall = tvFunctionCallTemplate;

         CodeTypeRef tvPropertyType = originalClassCodeProperty.Type;

         string tvPropertyTypeAsString = tvPropertyType.AsString;

         tvFunctionCall = string.Format(tvFunctionCall, ((CodeClass)originalClassCodeProperty.Parent).Name, originalClassCodeProperty.Name, tvPropertyTypeAsString);

         bodyStartingPoint =
            unitTestCodeFunction.GetStartPoint(vsCMPart.vsCMPartBody);

         boydEditPoint = bodyStartingPoint.CreateEditPoint();

         //FIX ME (tabing)
         boydEditPoint.Insert(StringHelper.GetTabString() + tvFunctionCall + Environment.NewLine);

         //FIX ME (tabing)
         string tvTempString = string.Empty; // "iv{0}Type.{1}, default({2})";
         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               tvTempString = "iv{0}Type.{1}, default({2})";
               break;
            case UnitTestCodeType.VB:
               tvTempString = "iv{0}Type.{1}, New {2}()";
               break;
            default:
               break;
         }

         tvTempString = string.Format(tvTempString, ((CodeClass)originalClassCodeProperty.Parent).Name, originalClassCodeProperty.Name, tvPropertyTypeAsString);

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
                 boydEditPoint.Insert(Environment.NewLine);
                 
                 boydEditPoint.Insert("\t\t\t// TODO: Update Assert to meet test needs" + Environment.NewLine);
                 
                 boydEditPoint.Insert("\t\t\t//Assert.AreEqual(" + tvTempString + ");" + Environment.NewLine);

                 boydEditPoint.Insert("\t\t\t" + Environment.NewLine);
                 
                 boydEditPoint.Insert("\t\t\tthrow new Exception(\"Not Implemented\");" + Environment.NewLine);
               break;
            case UnitTestCodeType.VB:
               boydEditPoint.Insert(Environment.NewLine);
               
               boydEditPoint.Insert("\t\t\t'TODO: Update Assert to meet test needs" + Environment.NewLine);
               
               boydEditPoint.Insert("\t\t\t'Assert.AreEqual(" + tvTempString + ")" + Environment.NewLine);

               boydEditPoint.Insert("\t\t\t" + Environment.NewLine);
               
               boydEditPoint.Insert("\t\t\tThrow New Exception 'Not Implemented'" + Environment.NewLine);
               break;
            default:
               break;
         }

         return unitTestCodeFunction;
      }



   }
}
