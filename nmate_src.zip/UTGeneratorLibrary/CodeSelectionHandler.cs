﻿

using System;
using System.Collections.Generic;
using System.Text;

using Extensibility;
using EnvDTE;
using EnvDTE80;

using UTGHelper;
using UTGManagerAndExaminor;


namespace UTGeneratorLibrary
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   /// </summary>
   public static class CodeSelectionHandler
   {
      internal static void OnGenerationStart(DTE2 applicationObject)
      {
         applicationObject.StatusBar.Text = "Staring generation of Unit Test/s...";
      }

      internal static void OnGenerationFaliure(DTE2 applicationObject)
      {
         applicationObject.StatusBar.Text = "Unable to complete generation of Unit Test/s...";
      }

      internal static bool CanGenerateHandleCodeFunction(CodeClass parentCodeClass, CodeFunction codeFunction, Project unitTestProject)
      {
         foreach (ProjectItem projectItem in unitTestProject.ProjectItems)
         {
            List<CodeClass> lstProjectCodeClasses = UTGManagerAndExaminor.ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

            foreach (CodeClass codeClass in lstProjectCodeClasses)
            {
               if ((parentCodeClass.Name + CommonStrings.DEFAULT_STRING_SEPERATOR + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX).Equals(codeClass.Name))
               {
                  foreach (CodeElement codeElement in codeClass.Members)
                  {
                     if (codeElement is CodeFunction)
                     {
                        if (codeFunction.Name.Equals(((CodeFunction)codeElement).Name))
                           return false;

                     }
                  }
               }
            }
         }

         return true;
      }


      internal static bool CanGenerateHandleCodeFunction(CodeClass parentCodeClass, string codeFunctionName)
      {

         foreach (CodeElement codeElement in parentCodeClass.Members)
         {
            if (codeElement is CodeFunction)
            {
               if (codeFunctionName.Equals(((CodeFunction)codeElement).Name))
                  return false;

            }
         }

         return true;
      }

      internal static bool CanGenerateHandleCodeProperty(CodeClass parentCodeClass, CodeProperty codeProperty, Project unitTestProject)
      {
         foreach (ProjectItem projectItem in unitTestProject.ProjectItems)
         {
            List<CodeClass> lstProjectCodeClasses = UTGManagerAndExaminor.ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

            foreach (CodeClass codeClass in lstProjectCodeClasses)
            {
               if ((parentCodeClass.Name + CommonStrings.DEFAULT_STRING_SEPERATOR + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX).Equals(codeClass.Name))
               {
                  foreach (CodeElement codeElement in codeClass.Members)
                  {
                     if (codeElement is CodeProperty)
                     {
                        if (codeProperty.Name.Equals(((CodeProperty)codeElement).Name))
                           return false;

                     }
                  }
               }
            }
         }

         return true;
      }


      internal static bool CanGenerateHandleCodeClass(CodeClass ce, Project unitTestProject)
      {
         foreach (ProjectItem projectItem in unitTestProject.ProjectItems)
         {
            List<CodeClass> lstProjectCodeClasses = UTGManagerAndExaminor.ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

            foreach (CodeClass codeClass in lstProjectCodeClasses)
            {
               if ((ce.Name + CommonStrings.DEFAULT_STRING_SEPERATOR + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX).Equals(codeClass.Name))
                  return false;
            }
         }

         return true;

      }

      internal static void OnCodeElementSelection(Project project, ref DTE2 applicationObject, UnitTestCodeType codeType/*, System.ComponentModel.License license*/)
      {
         try
         {
            foreach (ProjectItem pItem in project.ProjectItems)
            {
               try
               {
                 
                  foreach (CodeElement tvCodeElementOutter in pItem.FileCodeModel.CodeElements)
                  {
                     if (tvCodeElementOutter is CodeNamespace)
                     {
                        try
                        {
                           foreach (CodeElement tvCodeElement in ((CodeNamespace)tvCodeElementOutter).Members)
                           {
                              if (tvCodeElement != null &&
                                 tvCodeElement is CodeClass
                                 )
                              {
                                 try
                                 {
                                    if( ((CodeClass)tvCodeElement).Access == vsCMAccess.vsCMAccessPublic)
                                       OnCodeClassSelection((CodeClass)tvCodeElement, ref applicationObject, codeType/*, license*/);
                                 }
                                 catch (Exception ex)
                                 {
                                    ErrorHandler.LogException(ex);

                                    //ignore
                                    UTGHelper.ErrorHandler.HandleException(ex);
                                    return;
                                 }
                              }
                           }
                        }
                        catch (Exception ex)
                        {
                           //ignore this 
                           ErrorHandler.LogException(ex);

                        }
                     }
                     else if (tvCodeElementOutter is CodeClass)
                     {
                        try
                        {
                           if (((CodeClass)tvCodeElementOutter).Access == vsCMAccess.vsCMAccessPublic)
                              OnCodeClassSelection((CodeClass)tvCodeElementOutter, ref applicationObject, codeType/*, license*/);
                        }
                        catch (Exception ex)
                        {
                           ErrorHandler.LogException(ex);

                           //ignore
                           UTGHelper.ErrorHandler.HandleException(ex);
                           return;
                        }
                     }

                  }//if (tvCodeElementOutter is CodeNamespace)
               }
               catch (Exception ex)
               {
                  //ignore this on;
                  ErrorHandler.LogException(ex);
               }

            }//foreach (ProjectItem pItem in project.ProjectItems)

         }//first try
         catch (Exception ex)
         {
            //ignore this on;throw;
            ErrorHandler.LogException(ex);
         }
      }

      internal static void OnCodeElementSelection(CodeElement ce, ref DTE2 applicationObject, UnitTestCodeType codeType/*, System.ComponentModel.License license*/)
      {
         OnGenerationStart(applicationObject);

         if (ce is CodeNamespace)
         {
            ErrorHandler.ShowMessage(string.Format("You have selected the namesapce {0}! Currently there are no features which support namespaces.", ((CodeNamespace)ce).FullName));
         }
         //else if (codeClass != null)
         else if (ce is CodeClass)
         {
            if ( ((CodeClass)ce).Access != vsCMAccess.vsCMAccessPublic)
               return;

            OnCodeClassSelection((CodeClass)ce, ref applicationObject, codeType/*, license*/);
         }
         //else if (codeFunction != null)
         else if (ce is CodeFunction)
         {
            if ( ((CodeFunction)ce).Access != vsCMAccess.vsCMAccessPublic)
               return;

            OnCodeClassSelection((CodeFunction)ce, ref applicationObject, codeType/*, license*/);
         }
         else if (ce is CodeEnum)
         {
            if ( ((CodeEnum)ce).Access != vsCMAccess.vsCMAccessPublic)
               return;

            ErrorHandler.ShowMessage(string.Format("You have selected the Enum {0}!", ((CodeEnum)ce).FullName));
         }
         else if (ce is CodeStruct)
         {
            ErrorHandler.ShowMessage(string.Format("You have selected the Structure {0}!", ((CodeStruct)ce).FullName));
         }
         else if (ce is CodeProperty)
         {
            if ( ((CodeProperty)ce).Access != vsCMAccess.vsCMAccessPublic)
               return;

            OnCodeClassSelection((CodeProperty)ce, ref applicationObject, codeType);
         }
         else
         {
            ErrorHandler.ShowMessage(UTGHelper.CommonErrors.ERR_ILLEGAL_TEXT_SELECTION);
         }
      }


      internal static void OnCodeClassSelection(CodeFunction ce, ref DTE2 applicationObject, UnitTestCodeType codeType/*, System.ComponentModel.License license*/)
      {

         Project parentProject = ProjectExaminar.GetCodeClassParentProject((CodeClass)ce.Parent);

         Project unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         if (unitTestProject == null)
         {
            OnCodeClassSelection((CodeClass)ce.Parent, (CodeElement)ce, ref applicationObject, codeType/*, license*/);
            return;
         }
         
         //In cases where we can not simply generate automatically (definition already exists) we will
         //ask the user for input, wait on input, then async back to the function actuall usefull handler
         //HandelCodeClassSelection
         if (!CanGenerateHandleCodeFunction((CodeClass)ce.Parent, ce, unitTestProject))
         {
            //UTGHelper.ErrorHandler.HandleMessage(CommonUserMessages.MSG_TEST_ALREADY_EXISTS);

            UTGHelper.UserAlertActionRequired tvUserAlertActionRequired = new UserAlertActionRequired(
               "Function definition already exits! What would you like to do?", 
               typeof(CodeFunction), 
               (CodeElement)ce,
               ref applicationObject,
               codeType);

            if (!tvUserAlertActionRequired.IsDisposed)
            {
               tvUserAlertActionRequired.FormClosed += new System.Windows.Forms.FormClosedEventHandler(tvUserAlertActionRequired_FormClosed);

               tvUserAlertActionRequired.Show();
            }
            else
            {
               HandelCodeClassSelection(ce, applicationObject, codeType);
            }

            return;
         }

         //otherwize simply call HandelCodeClassSelection
         HandelCodeClassSelection(ce, applicationObject, codeType);

         #region older code...
         //foreach (ProjectItem projectItem in unitTestProject.ProjectItems)
         //{
         //   System.Collections.Generic.List<CodeClass> lstCodeClasses =
         //        ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

         //   foreach (CodeClass codeClass in lstCodeClasses)
         //   {
         //      if (codeClass.Name.Equals(((CodeClass)ce.Parent).Name + CommonStrings.DEFAULT_STRING_SEPERATOR + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX))
         //      {

         //         CodeFunction codeFunction = UnitTestGenerator.GenerateTest(codeClass, ce);

         //         //write new file to disk

         //         //ProjectItem projItem = codeClass.ProjectItem; //fiel name xyz.cs

         //         UTGHelper.InputOutput.writeFile(codeClass.FullName, codeClass.ToString());

         //         string fileToOpen =
         //           UTGManagerAndExaminor.ProjectExaminar.GetProjectPath(codeClass.ProjectItem.ContainingProject) + "\\" + codeClass.ProjectItem.Name;

         //         applicationObject.ItemOperations.OpenFile(fileToOpen, EnvDTE.Constants.vsViewKindAny);
         //      }
         //   }
         //}
         #endregion
      }


      internal static void OnCodeClassSelection(CodeProperty ce, ref DTE2 applicationObject, UnitTestCodeType codeType/*, System.ComponentModel.License license*/)
      {

         Project parentProject = ProjectExaminar.GetCodeClassParentProject((CodeClass)ce.Parent);

         Project unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         if (unitTestProject == null)
         {
            OnCodeClassSelection((CodeClass)ce.Parent, (CodeElement)ce, ref applicationObject, codeType/*, license*/);
            return;
         }

         //In cases where we can not simply generate automatically (definition already exists) we will
         //ask the user for input, wait on input, then async back to the function actuall usefull handler
         //HandelCodeClassSelection
         if (!CanGenerateHandleCodeProperty((CodeClass)ce.Parent, ce, unitTestProject))
         {
            //UTGHelper.ErrorHandler.HandleMessage(CommonUserMessages.MSG_TEST_ALREADY_EXISTS);

            UTGHelper.UserAlertActionRequired tvUserAlertActionRequired = new UserAlertActionRequired(
               "Property definition already exits! What would you like to do?",
               typeof(CodeProperty),
               (CodeElement)ce,
               ref applicationObject,
               codeType);

            if (!tvUserAlertActionRequired.IsDisposed)
            {
               tvUserAlertActionRequired.FormClosed += new System.Windows.Forms.FormClosedEventHandler(tvUserAlertActionRequired_FormClosed);

               tvUserAlertActionRequired.Show();
            }
            else
            {
               HandelCodeClassSelection(ce, applicationObject, codeType);
            }

            return;
         }

         //otherwize simply call HandelCodeClassSelection
         HandelCodeClassSelection(ce, applicationObject, codeType);

      }


      /// <summary>
      /// Very close to overloaded except that this is used in cases where a code function or a property is selected
      /// and the parent class has not been yet generated, however the unit test project does exists.
      /// </summary>
      /// <param name="ce">The code class from which we will generate</param>
      /// <param name="cElement">The code element chosen. Either CodeFunction or CodeProperty</param>
      /// <param name="applicationObject">The application object</param>
      /// <param name="unitTestProject">The Unit Test Project which already exits for this class' unit test</param>
      internal static void OnCodeClassSelection(CodeClass ce, CodeElement cElement, ref DTE2 applicationObject, Project unitTestProject, UnitTestCodeType codeType/*, System.ComponentModel.License license*/)
      {
         if (ce.Access != vsCMAccess.vsCMAccessPublic)
            return;

         Project parentProject = ProjectExaminar.GetCodeClassParentProject(ce);

         string unitTestClassShell = UnitTestGenerator.GenerateTestShell((CodeClass)ce, codeType);

         if (unitTestProject != null && !CanGenerateHandleCodeClass(ce, unitTestProject))
         {
            UTGHelper.ErrorHandler.ShowMessage(CommonUserMessages.MSG_TEST_ALREADY_EXISTS);

            OnGenerationFaliure(applicationObject);

            return;
         }

         string path = UnitTestGenerator.GetUnitTestProjectPath(parentProject.Name, ref applicationObject);

         path = UTGHelper.FileInputOutput.GetFilePath(path);

         System.IO.DirectoryInfo newDirectoryInfo = null;

         string fileExtension = string.Empty;

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               fileExtension = UTGHelper.CommonStrings.DEFAULT_CODE_FILE_EXTENSION;
               break;
            case UnitTestCodeType.VB:
               fileExtension = UTGHelper.CommonStrings.DEFAULT_CODE_VB_FILE_EXTENSION;
               break;
            default:
               break;
         }

         try
         {
            //Try to create a unit test project. If one exits this should natuarly throw! 
            //In other words is there an exiting unit test project directory

            //Another way of doing this would be to try and find this project in current open solution

            //Either case we have one by now so lets get its directory information
            newDirectoryInfo = new System.IO.DirectoryInfo(path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME);
         }
         catch (Exception ex)
         {
            ErrorHandler.LogException(ex);
         }

         //If for whatever resoan we are still failing then simply quit this 
         if (newDirectoryInfo == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception(string.Format("Unable to create new Directory {0}", path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME));
         }


         //write new file to disk
         UTGHelper.InputOutput.writeFile(newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension, unitTestClassShell);

         //Calling our UnitTestGenerator AddClassToProject method...
         ProjectItem projectItem = UnitTestGenerator.AddClassToProject(ref applicationObject, ref unitTestProject, null, newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension/*, license*/ );

         System.Collections.Generic.List<CodeClass> lstCodeClasses = ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

         //IF ANYTHING GOES WROING THEN LOOK HERE FIRST
         CodeClass unitTestCodeClass = UnitTestGenerator.GenerateTest(lstCodeClasses[0], (CodeClass)ce, cElement, codeType);

         //write new file to disk
         InputOutput.writeFile(newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + CommonStrings.DEFAULT_CODE_FILE_EXTENSION, unitTestCodeClass.ToString());

         if (projectItem == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception(string.Format("Unable to create and add file {0} to project {2}", ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX, applicationObject.Name));
         }

         //Add unit nunit.framework.dll ref
         string tvTempUnitTestFolderHolder = 
            InstalledSoftware.GetNUnitBinariesFolder();

         if (!tvTempUnitTestFolderHolder.Equals(string.Empty))
         {
            VSLangProj.Reference nunitReferance =
               ProjectManager.AddDllReferenceToProject(unitTestProject, tvTempUnitTestFolderHolder + CommonStrings.UNIT_TEST_DLL_FILENAME);
         }

         //add origianl projects outputted dll
         string tvTempOriginalProjectOutputDll =
            UTGManagerAndExaminor.ProjectExaminar.GetProjectOutputFullAssemblyName(parentProject);

         ProjectManager.AddDllReferenceToProject(unitTestProject, tvTempOriginalProjectOutputDll);

         //add origianl projects refs

         VSLangProj.References references = ProjectManager.GetProjectReferences(parentProject);

         ProjectManager.AddReferencesToProject(references, unitTestProject);

         //if (nunitReferance == null)
         //   throw new Exception(string.Format("Unable to add the NUnit dll reference to your project {0}. Please add it manually!", ((CodeClass)ce).Name +
         //   UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX, applicationObject.Name));


         applicationObject.ItemOperations.OpenFile(
            newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension
            , EnvDTE.Constants.vsViewKindAny);

      }


      /// <summary>
      /// Nearly identical to overloaded but without the CodeElement parameter. Difference is that this
      /// will create a new class with a single test only for CodeElement.
      /// </summary>
      /// <param name="ce"></param>
      /// <param name="cElement"></param>
      /// <param name="applicationObject"></param>
      internal static void OnCodeClassSelection(CodeClass ce, CodeElement cElement, ref DTE2 applicationObject, UnitTestCodeType codeType/*, System.ComponentModel.License license*/)
      {
         if (ce.Access != vsCMAccess.vsCMAccessPublic)
            return;

         Project parentProject = ProjectExaminar.GetCodeClassParentProject(ce);

         string unitTestClassShell = UnitTestGenerator.GenerateTestShell((CodeClass)ce, codeType);

         Project unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         if (unitTestProject != null && !CanGenerateHandleCodeClass(ce, unitTestProject))
         {
            UTGHelper.ErrorHandler.ShowMessage(CommonUserMessages.MSG_TEST_ALREADY_EXISTS);

            OnGenerationFaliure(applicationObject);

            return;
         }

         string path = UnitTestGenerator.GetUnitTestProjectPath(parentProject.Name, ref applicationObject);
         path = UTGHelper.FileInputOutput.GetFilePath(path);

         System.IO.DirectoryInfo newDirectoryInfo;

         string fileExtension = string.Empty;

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               fileExtension = UTGHelper.CommonStrings.DEFAULT_CODE_FILE_EXTENSION;
               break;
            case UnitTestCodeType.VB:
               fileExtension = UTGHelper.CommonStrings.DEFAULT_CODE_VB_FILE_EXTENSION;
               break;
            default:
               break;
         }

         try
         {
            //Try to create a unit test project. If one exits this should natuarly throw! 
            //In other words is there an exiting unit test project directory

            //Another way of doing this would be to try and find this project in current open solution

            newDirectoryInfo =
               System.IO.Directory.CreateDirectory(path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME);
         }
         catch (Exception ex)
         {
            ErrorHandler.LogException(ex);
         }
         finally
         {
            //Either case we have one by now so lets get its directory information
            newDirectoryInfo = new System.IO.DirectoryInfo(path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME);
         }

         //If for whatever resoan we are still failing then simply quit this 
         if (newDirectoryInfo == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception(string.Format("Unable to create new Directory {0}", path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME));
         }

         if (unitTestProject == null)
            unitTestProject = UnitTestGenerator.CreateAndAddUnitTestProject((Solution2)applicationObject.Solution, parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME, newDirectoryInfo.FullName, codeType/*, license*/);

         //for some resoan, newUnitTestProject is being returned null!
         //Don't use it!


         //Since above operation fails in either case then try getting the new Unit Test Project if created and added ok..
         if (unitTestProject == null)
            unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         if (unitTestProject == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception("Can not create new UnitTest Project");
         }

         //write new file to disk
         UTGHelper.InputOutput.writeFile(newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension, unitTestClassShell);

         //Calling our UnitTestGenerator AddClassToProject method...
         ProjectItem projectItem = UnitTestGenerator.AddClassToProject(ref applicationObject, ref unitTestProject, null, newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension/*, license*/);

         System.Collections.Generic.List<CodeClass> lstCodeClasses = ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

         //IF ANYTHING GOES WROING THEN LOOK HERE FIRST
         CodeClass unitTestCodeClass = UnitTestGenerator.GenerateTest(lstCodeClasses[0], (CodeClass)ce, cElement, codeType);

         //write new file to disk
         UTGHelper.InputOutput.writeFile(newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension, unitTestCodeClass.ToString());

         if (projectItem == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception(string.Format("Unable to create and add file {0} to project {2}", ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX, applicationObject.Name));
         }

         //Add unit nunit.framework.dll ref
         string tvTempUnitTestFolderHolder =
            InstalledSoftware.GetNUnitBinariesFolder();

         if (!tvTempUnitTestFolderHolder.Equals(string.Empty))
         {
            VSLangProj.Reference nunitReferance =
               ProjectManager.AddDllReferenceToProject(unitTestProject, tvTempUnitTestFolderHolder +  CommonStrings.UNIT_TEST_DLL_FILENAME);
         }

         //add origianl projects outputted dll
         string tvTempOriginalProjectOutputDll =
            UTGManagerAndExaminor.ProjectExaminar.GetProjectOutputFullAssemblyName(parentProject);

         ProjectManager.AddDllReferenceToProject(unitTestProject, tvTempOriginalProjectOutputDll);

         //add origianl projects refs
         VSLangProj.References references = ProjectManager.GetProjectReferences(parentProject);

         ProjectManager.AddReferencesToProject(references, unitTestProject);

         //if (nunitReferance == null)
         //   throw new Exception(string.Format("Unable to add the NUnit dll reference to your project {0}. Please add it manually!", ((CodeClass)ce).Name +
         //   UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX, applicationObject.Name));


         applicationObject.ItemOperations.OpenFile(
            newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension
            , EnvDTE.Constants.vsViewKindAny);

      }

      internal static void OnCodeClassSelection(CodeClass ce, ref DTE2 applicationObject, UnitTestCodeType codeType/*, System.ComponentModel.License license*/)
      {
         //OnGenerationStart(applicationObject);

         if (ce.Access != vsCMAccess.vsCMAccessPublic)
            return;

         Project parentProject = ProjectExaminar.GetCodeClassParentProject(ce);

         string unitTestClassShell = UnitTestGenerator.GenerateTestShell((CodeClass)ce, codeType);

         Project unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         if (unitTestProject != null && !CanGenerateHandleCodeClass(ce, unitTestProject))
         {
            UTGHelper.ErrorHandler.ShowMessage(CommonUserMessages.MSG_TEST_ALREADY_EXISTS);

            OnGenerationFaliure(applicationObject);

            return;
         }

         string path = UnitTestGenerator.GetUnitTestProjectPath(parentProject.Name, ref applicationObject);
         path = UTGHelper.FileInputOutput.GetFilePath(path);

         System.IO.DirectoryInfo newDirectoryInfo;

         string fileExtension = string.Empty;

         switch (codeType)
         {
            case UnitTestCodeType.CSharp:
               fileExtension = UTGHelper.CommonStrings.DEFAULT_CODE_FILE_EXTENSION;
               break;
            case UnitTestCodeType.VB:
               fileExtension = UTGHelper.CommonStrings.DEFAULT_CODE_VB_FILE_EXTENSION;
               break;
            default:
               break;
         }

         try
         {
            //Try to create a unit test project. If one exits this should natuarly throw! 
            //In other words is there an exiting unit test project directory

            //Another way of doing this would be to try and find this project in current open solution

            newDirectoryInfo =
               System.IO.Directory.CreateDirectory(path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME);
         }
         catch (Exception ex) 
         {
            ErrorHandler.LogException(ex);
         }
         finally
         {
            //Either case we have one by now so lets get its directory information
            newDirectoryInfo = new System.IO.DirectoryInfo(path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME);
         }

         //If for whatever resoan we are still failing then simply quit this 
         if (newDirectoryInfo == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception(string.Format("Unable to create new Directory {0}", path + "\\" + parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME));
         }

         if (unitTestProject == null)
         {
            try
            {
               unitTestProject = UnitTestGenerator.CreateAndAddUnitTestProject((Solution2)applicationObject.Solution, parentProject.Name + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_PROJECT_NAME, newDirectoryInfo.FullName, codeType/*, license*/);
            }
            catch (Exception ex)
            {
               ErrorHandler.LogException(ex);

               OnGenerationFaliure(applicationObject);

               throw;
            }
         }
         //for some resoan, newUnitTestProject is being returned null!
         //Don't use it!


         //Since above operation fails in either case then try getting the new Unit Test Project if created and added ok..
         if (unitTestProject == null)
            unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         if (unitTestProject == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception("Can not create new UnitTest Project");
         }

         //write new file to disk
         UTGHelper.InputOutput.writeFile(newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension, unitTestClassShell);

         //Calling our UnitTestGenerator AddClassToProject method...
         ProjectItem projectItem = UnitTestGenerator.AddClassToProject(ref applicationObject, ref unitTestProject, null, newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension/*, license*/);

         System.Collections.Generic.List<CodeClass> lstCodeClasses = ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

         //IF ANYTHING GOES WROING THEN LOOK HERE FIRST
         CodeClass unitTestCodeClass = UnitTestGenerator.GenerateTest(lstCodeClasses[0], (CodeClass)ce, codeType);

         //write new file to disk
         UTGHelper.InputOutput.writeFile(newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension, unitTestCodeClass.ToString());

         if (projectItem == null)
         {
            OnGenerationFaliure(applicationObject);

            throw new Exception(string.Format("Unable to create and add file {0} to project {2}", ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX, applicationObject.Name));
         }

         //Add unit nunit.framework.dll ref
         string tvTempUnitTestFolderHolder =
            InstalledSoftware.GetNUnitBinariesFolder();

         if (!tvTempUnitTestFolderHolder.Equals(string.Empty))
         {
            VSLangProj.Reference nunitReferance =
               ProjectManager.AddDllReferenceToProject(unitTestProject, tvTempUnitTestFolderHolder + CommonStrings.UNIT_TEST_DLL_FILENAME);
         }

         //add origianl projects outputted dll
         string tvTempOriginalProjectOutputDll =
            UTGManagerAndExaminor.ProjectExaminar.GetProjectOutputFullAssemblyName(parentProject);

         ProjectManager.AddDllReferenceToProject(unitTestProject, tvTempOriginalProjectOutputDll);

         //add origianl projects refs
         VSLangProj.References references = ProjectManager.GetProjectReferences(parentProject);

         ProjectManager.AddReferencesToProject(references, unitTestProject);

         //if (nunitReferance == null)
         //   throw new Exception(string.Format("Unable to add the NUnit dll reference to your project {0}. Please add it manually!", ((CodeClass)ce).Name +
         //   UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX, applicationObject.Name));


         applicationObject.ItemOperations.OpenFile(
            newDirectoryInfo.FullName + "\\" + ((CodeClass)ce).Name +
            UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX + fileExtension
            , EnvDTE.Constants.vsViewKindAny);

      }


      internal static void HandelCodeClassSelection(CodeFunction ce, DTE2 applicationObject, UnitTestCodeType codeType)
      {
         Project parentProject = ProjectExaminar.GetCodeClassParentProject((CodeClass)ce.Parent);

         Project unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         foreach (ProjectItem projectItem in unitTestProject.ProjectItems)
         {
            System.Collections.Generic.List<CodeClass> lstCodeClasses =
                 ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

            foreach (CodeClass codeClass in lstCodeClasses)
            {
               if (codeClass.Name.Equals(((CodeClass)ce.Parent).Name + CommonStrings.DEFAULT_STRING_SEPERATOR + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX))
               {

                  CodeFunction codeFunction = UnitTestGenerator.GenerateTest(codeClass, ce, codeType);

                  //write new file to disk

                  //ProjectItem projItem = codeClass.ProjectItem; //fiel name xyz.cs

                  UTGHelper.InputOutput.writeFile(codeClass.FullName, codeClass.ToString());

                  string fileToOpen =
                    UTGManagerAndExaminor.ProjectExaminar.GetProjectPath(codeClass.ProjectItem.ContainingProject) + "\\" + codeClass.ProjectItem.Name;

                  applicationObject.ItemOperations.OpenFile(fileToOpen, EnvDTE.Constants.vsViewKindAny);

                  //we sure expect just one class, the first class we find matching
                  return;
               }
            }

            //if we have reached this point then it means that we have not been able to locate a parent class in our
            //unit test project, then we simply create a class unit test
            //OnCodeClassSelection((CodeClass)ce.Parent, (CodeElement)ce, ref applicationObject, unitTestProject, codeType);
         }

         //if we have reached this point then it means that we have not been able to locate a parent class in our
         //unit test project, then we simply create a class unit test

         OnCodeClassSelection((CodeClass)ce.Parent, (CodeElement)ce, ref applicationObject, unitTestProject, codeType);
      }


      internal static void HandelCodeClassSelection(CodeProperty ce, DTE2 applicationObject, UnitTestCodeType codeType)
      {
         Project parentProject = ProjectExaminar.GetCodeClassParentProject((CodeClass)ce.Parent);

         Project unitTestProject = ProjectExaminar.GetUnitTestProject(parentProject.Name, applicationObject);

         foreach (ProjectItem projectItem in unitTestProject.ProjectItems)
         {
            System.Collections.Generic.List<CodeClass> lstCodeClasses =
                 ProjectItemExaminor.GetCodeClasses(projectItem.FileCodeModel);

            foreach (CodeClass codeClass in lstCodeClasses)
            {
               if (codeClass.Name.Equals(((CodeClass)ce.Parent).Name + CommonStrings.DEFAULT_STRING_SEPERATOR + UTGHelper.CommonStrings.DEFAULT_UNIT_TEST_CLASS_POSTFIX))
               {
                  CodeFunction codeFunction = UnitTestGenerator.GenerateTest(codeClass, ce, codeType);

                  //write new file to disk

                  //ProjectItem projItem = codeClass.ProjectItem; //fiel name xyz.cs

                  UTGHelper.InputOutput.writeFile(codeClass.FullName, codeClass.ToString());

                  string fileToOpen =
                    UTGManagerAndExaminor.ProjectExaminar.GetProjectPath(codeClass.ProjectItem.ContainingProject) + "\\" + codeClass.ProjectItem.Name;

                  applicationObject.ItemOperations.OpenFile(fileToOpen, EnvDTE.Constants.vsViewKindAny);

                  //we sure expect just one class, the first class we find matching
                  return;
               }
            }

            //if we have reached this point then it means that we have not been able to locate a parent class in our
            //unit test project, then we simply create a class unit test

            //OnCodeClassSelection((CodeClass)ce.Parent, (CodeElement)ce, ref applicationObject, unitTestProject, codeType);
         }

         //if we have reached this point then it means that we have not been able to locate a parent class in our
         //unit test project, then we simply create a class unit test

         OnCodeClassSelection((CodeClass)ce.Parent, (CodeElement)ce, ref applicationObject, unitTestProject, codeType);
      }


      static void tvUserAlertActionRequired_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
      {
         UTGHelper.UserAlertActionRequired tvUserAlertActionRequired = (UTGHelper.UserAlertActionRequired)sender;

         if (tvUserAlertActionRequired.ApplicableAcctionState == UserAlertActionRequired.ApplicableAcction.ignore)
            return;

         if(tvUserAlertActionRequired.ApplicableAcctionState == UserAlertActionRequired.ApplicableAcction.mutate)
            HandelCodeClassSelection((CodeFunction)tvUserAlertActionRequired.FormCodeElement, tvUserAlertActionRequired.FormApplicationObject, (UnitTestCodeType)tvUserAlertActionRequired.FromCodeType);
      }



   }
}
