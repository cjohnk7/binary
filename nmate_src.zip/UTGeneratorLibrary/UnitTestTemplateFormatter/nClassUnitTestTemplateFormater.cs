﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UTGeneratorLibrary.UnitTestTemplateFormatter
{
   /// <summary>
   /// Helper class for nClassUnitTestTemplate formatting
   /// </summary>
   public static class nClassUnitTestTemplateFormater
   {
      /// <summary>
      /// This source is under the New BSD License
      /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License. 
      ///{0} Namespace
      ///{1} Class
      ///{2} Member to test
      ///{3} Datetime generated
      /// </summary>
      /// <param name="templateContent"></param>
      /// <param name="nameSpace"></param>
      /// <param name="className"></param>
      /// <param name="memeberToTest"></param>
      /// <param name="dateTime"></param>
      /// <returns></returns>
      public static string FormateTemplate(string templateContent, string nameSpace, string className, string dateTime)
      {
         if (templateContent.Equals(string.Empty))
            throw new Exception("Invalid parameter templateContent");

         if (nameSpace.Equals(string.Empty))
            throw new Exception("Invalid parameter nameSpace");

         if (className.Equals(string.Empty))
            throw new Exception("Invalid parameter className");

         templateContent = templateContent.Replace("{0}", nameSpace);
         templateContent = templateContent.Replace("{1}", className);
         templateContent = templateContent.Replace("{2}", dateTime);
         templateContent = templateContent.Replace("{1000}", UTGHelper.CommonStrings.APPLICATION_NAME);

         return templateContent;
      }

      public static string FormateTemplateForShared(string templateContent, string nameSpace, string className, string dateTime)
      {
         if (templateContent.Equals(string.Empty))
            throw new Exception("Invalid parameter templateContent");

         if (nameSpace.Equals(string.Empty))
            throw new Exception("Invalid parameter nameSpace");

         if (className.Equals(string.Empty))
            throw new Exception("Invalid parameter className");

         //remove these first since order matters here...
         templateContent = templateContent.Replace("iv{1}Type = New {1}()", string.Empty);
         templateContent = templateContent.Replace("iv{1}Type = Nothing", string.Empty);
         templateContent = templateContent.Replace("Dim iv{1}Type As {1}", string.Empty);
         templateContent = templateContent.Replace("private {1} iv{1}Type;", string.Empty);
         templateContent = templateContent.Replace("iv{1}Type = new {1}();", string.Empty);
         templateContent = templateContent.Replace("iv{1}Type = null;", string.Empty);


         templateContent = templateContent.Replace("{0}", nameSpace);
         templateContent = templateContent.Replace("{1}", className);
         templateContent = templateContent.Replace("{2}", dateTime);
         templateContent = templateContent.Replace("{1000}", UTGHelper.CommonStrings.APPLICATION_NAME);

        
         return templateContent;
      }
   }
}
