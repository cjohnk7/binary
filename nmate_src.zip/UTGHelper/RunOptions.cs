using System;
using System.Collections.Generic;
using System.Text;

using Extensibility;
using EnvDTE;
using EnvDTE80;

namespace UTGHelper
{
   public class RunOptions
   {
      private bool ivDebugging = false;
      Project ivProject = null;
      List<CodeClass> ivCodeClasses = new List<CodeClass>();
      List<CodeFunction> ivCodeFunctions = new List<CodeFunction>();
      private string ivConfigurationFile = string.Empty;

      public string IvConfigurationFile
      {
         get { return ivConfigurationFile; }
         set { ivConfigurationFile = value; }
      }

      public void Initialize()
      {
         ivDebugging = false;

         ivProject = null;

         if (ivCodeClasses != null)
            ivCodeClasses.Clear();
         else
            ivCodeClasses = new List<CodeClass>();

         if (ivCodeFunctions != null)
            ivCodeFunctions.Clear();
         else
            ivCodeFunctions = new List<CodeFunction>();
      }

      public bool IvDebugging
      {
         get { return ivDebugging; }
         set { ivDebugging = value; }
      }

      public Project IvProject
      {
         get { return ivProject; }
         set { ivProject = value; }
      }

      public List<CodeClass> IvCodeClasses
      {
         get { return ivCodeClasses; }
         set { ivCodeClasses = value; }
      }

      public List<CodeFunction> IvCodeFunctions
      {
         get { return ivCodeFunctions; }
         set { ivCodeFunctions = value; }
      }
   }
}
