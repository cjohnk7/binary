using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using Extensibility;
using EnvDTE;
using EnvDTE80;

using Microsoft.VisualStudio.Shell.Interop;

namespace UTGHelper
{
   public partial class ErrorsListUserControle : UserControl
   {
      public static List<UnitTestError> ErrorList = new  List<UnitTestError>();

      static ErrorsListUserControle()
      {
         //ErrorList.ListChangeEvent += new ListWithEvents<UnitTestError>.ListChangeDelegate(ErrorList_ListChangeEvent);
      }

      static void ErrorList_ListChangeEvent()
      {
      }

      public ErrorsListUserControle()
      {
         InitializeComponent();
      }

      static void dataGridView1_CellDoubleClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
      {
         ErrorTaskApplicationObject erroTask = null;

         try
         {
            erroTask =
               (ErrorTaskApplicationObject)dataGridView1.Rows[e.RowIndex].Cells[2].Value;
         }
         catch (Exception ex)
         {
            //gobble...
            ErrorHandler.LogException(ex);

            return;
         }

         try
         {
            if (erroTask != null && erroTask.TheErrorTask != null && erroTask.ApplicationObject != null)
            {
               erroTask.ApplicationObject.ItemOperations.OpenFile(erroTask.TheErrorTask.Document, EnvDTE.Constants.vsViewKindAny);

               TextSelection selection = erroTask.ApplicationObject.ActiveDocument.Selection as TextSelection;

               selection.GotoLine(erroTask.TheErrorTask.Line, true);
            }
         }
         catch (Exception ex)
         {
            //gobble...
            ErrorHandler.LogException(ex);
         }

      }

      void dataGridView1_DataError(object sender, System.Windows.Forms.DataGridViewDataErrorEventArgs e)
      {
         //do nothing but keep this in...
      }

      private void dataGridView1_ColumnHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
      {
         
      }

      private void dataGridView1_ColumnSortModeChanged(object sender, DataGridViewColumnEventArgs e)
      {
         
      }

      private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
      {

      }

      private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
      {
         
#region older code no longer in use...
         try
         {
            //System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyleNonSelected = new System.Windows.Forms.DataGridViewCellStyle();

            //dataGridViewCellStyleNonSelected.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            //dataGridViewCellStyleNonSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //dataGridViewCellStyleNonSelected.ForeColor = System.Drawing.SystemColors.ControlText;
            //dataGridViewCellStyleNonSelected.SelectionBackColor = System.Drawing.SystemColors.Window;
            //dataGridViewCellStyleNonSelected.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            //dataGridViewCellStyleNonSelected.WrapMode = System.Windows.Forms.DataGridViewTriState.True;


            //foreach (DataGridViewRow dataGridViewRow in dataGridView1.Rows)
            //{
            //   dataGridViewRow.DefaultCellStyle = dataGridViewCellStyleNonSelected;
            //}

            //dataGridView1.Refresh();

            //System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyleSelected = new System.Windows.Forms.DataGridViewCellStyle();
            //dataGridViewCellStyleSelected.BackColor = System.Drawing.SystemColors.GrayText;
            //dataGridViewCellStyleSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //dataGridViewCellStyleSelected.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            //dataGridViewCellStyleSelected.SelectionBackColor = System.Drawing.SystemColors.GrayText;
            //dataGridViewCellStyleSelected.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            //dataGridViewCellStyleSelected.WrapMode = System.Windows.Forms.DataGridViewTriState.True;

            //dataGridView1.Rows[e.RowIndex].DefaultCellStyle = dataGridViewCellStyleSelected;
            //dataGridView1.Refresh();
         }
         catch (Exception ex)
         {
            //gobble
            ErrorHandler.LogException(ex);
         }
#endregion

      }

      private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
      {
        
      }
   }
}
