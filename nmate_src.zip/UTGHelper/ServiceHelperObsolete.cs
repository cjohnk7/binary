﻿

using System;
using System.Collections.Generic;
using System.Text;

namespace UTGHelper
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   /// </summary>
   [Obsolete]
   class ServiceHelperObsolete
   {
      #region older commented-out code
      //internal object GetErrorService(Type service)
      //{
      //   return _taskList;
      //}

      //internal static IVsTaskList _taskList = null;

      //private ErrorTask CreateErrorTaks(string file, int line, int endLine, string description)
      //{
      //   ErrorTask errorTask = new ErrorTask();
      //   errorTask.Line = line;
      //   errorTask.Category = TaskCategory.BuildCompile;
      //   errorTask.Document = file;
      //   errorTask.Text = description;
      //   errorTask.Navigate += NavigateToError;
      //   return errorTask;
      //}

      //internal void NavigateToError(object sender, EventArgs e)
      //{
      //   ErrorTask error = sender as ErrorTask;

      //   //if (error != null && Project != null)
      //   //{
      //   //   _applicationObject.OpenFile(error.Document, false, error.Line, error.Column, error.EndLine, error.EndColumn);
      //   //}
      //}

      ///// <summary>
      ///// Seems to only work and return an object if a build is performed first in the case
      ///// of user just opening project file
      ///// </summary>
      ///// <param name="service"></param>
      ///// <returns></returns>
      //internal IVsTaskList Helper_Iffy_GetVsService(Type service)
      //{
      //   object obj = null;

      //   obj = GetErrorService(service);

      //   if (obj == null)
      //   {
      //      obj = Microsoft.VisualStudio.Shell.Package.GetGlobalService(service);
      //   }

      //   return _taskList = (IVsTaskList)obj;
      //}


      //internal List<IVsTaskItem> Helper_Iffy_GetIVsTaskItems()
      //{
      //   IVsTaskList errorList = (IVsTaskList)Helper_Iffy_GetVsService(typeof(SVsErrorList));

      //   IVsEnumTaskItems itemsEnum;
      //   errorList.EnumTaskItems(out itemsEnum);
      //   IVsTaskItem[] oneItem = new IVsTaskItem[1];
      //   List<IVsTaskItem> items = new List<IVsTaskItem>();

      //   int result = 0;

      //   do
      //   {
      //      result = itemsEnum.Next(1, oneItem, null);
      //      if (result == 0)
      //         items.Add(oneItem[0]);

      //   } while (result == 0);

      //   return items;
      //}

      //private IVsTaskList Helper_GetIVsTaskList()
      //{
      //   Object objService;

      //   IVsTaskList objIVsDataConnectionsService;

      //   objService = GetService(_applicationObject, typeof(IVsTaskList));

      //   objIVsDataConnectionsService = (IVsTaskList)objService;

      //   return objIVsDataConnectionsService;

      //}

      //private IVsErrorList Helper_GetIVsErrorList()
      //{
      //   Object objService;

      //   IVsErrorList objIVsDataConnectionsService;

      //   objService = GetService(_applicationObject, typeof(IVsErrorList));

      //   objIVsDataConnectionsService = (IVsErrorList)objService;

      //   return objIVsDataConnectionsService;

      //}

      //private IServiceProvider Helper_NotWorking_GetErrorListProvider()
      //{
      //   Object objService;

      //   IServiceProvider objIVsDataConnectionsService;

      //   objService = GetService(_applicationObject, typeof(IServiceProvider));

      //   objIVsDataConnectionsService = (IServiceProvider)objService;

      //   return objIVsDataConnectionsService;

      //}

      
      //public object GetService(object serviceProvider, System.Type type)
      //{
      //   return GetService(serviceProvider, type.GUID);
      //}



      //public object GetService(object serviceProvider, System.Guid guid)
      //{
      //   object objService = null;
      //   Microsoft.VisualStudio.OLE.Interop.IServiceProvider objIServiceProvider;
      //   IntPtr objIntPtr;
      //   int hr;

      //   Guid objSIDGuid;
      //   Guid objIIDGuid;

      //   objSIDGuid = guid;
      //   objIIDGuid = objSIDGuid;

      //   objIServiceProvider = (Microsoft.VisualStudio.OLE.Interop.IServiceProvider)serviceProvider;
      //   hr = objIServiceProvider.QueryService(ref objSIDGuid, ref objIIDGuid, out objIntPtr);

      //   if (hr != 0)
      //   {
      //      System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(hr);
      //   }
      //   if (!objIntPtr.Equals(IntPtr.Zero))
      //   {
      //      objService = System.Runtime.InteropServices.Marshal.GetObjectForIUnknown(objIntPtr);
      //      System.Runtime.InteropServices.Marshal.Release(objIntPtr);
      //   }

      //   return objService;
      //}
      #endregion
   }
}
