﻿
//#define _ENCRYPT_

using System;
using System.Collections.Generic;
using System.Text;

namespace UTGHelper
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   /// </summary>
   public static class ErrorHandler
   {
      public static string ivErrorFileShortName = "\\UTGSupport.txt";

      public static bool CanRun()
      {
         System.DateTime nowTime = System.DateTime.Now;
         System.DateTime then = new DateTime(2008, 05, 1);

         if (nowTime > then)
            return false;

         return true;
      }

      static public string GetFilePath(string fileFullName)
      {
         fileFullName = fileFullName.Replace("/", "\\");

         int lastIndexOfSlash = fileFullName.LastIndexOf("\\");

         if (lastIndexOfSlash >= 0)
         {
            return fileFullName.Substring(0, lastIndexOfSlash);
         }

         return string.Empty;
      }

      [Obsolete("Use LogException instead", true)]
      private static void LogMessage( string message)
      {
         try
         {
#if _ENCRYPT_
            message = UTGHelper.Helper.EncryptString(message, "support");
#endif

            string currentDirectiory = GetFilePath(
               System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase.Replace("file:///", "")
               );

            InputOutput.writeFileIfNotExistsAppending(currentDirectiory + ErrorHandler.ivErrorFileShortName, message);
         }
         catch (Exception) { }

      }

      /// <summary>
      /// Simply logs an exception silently. Use HandleException to alert user that an error has occured
      /// </summary>
      /// <param name="ex"></param>
      public static void LogException(Exception ex)
      {
         try
         {
            string currentDirectiory = GetFilePath(
               System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase.Replace("file:///", "")
               );

            string tvMessage = ex.Message;

#if _ENCRYPT_
            tvMessage = UTGHelper.Helper.EncryptString(tvMessage, "support");
#endif
            InputOutput.writeFileIfNotExistsAppending(currentDirectiory + ErrorHandler.ivErrorFileShortName, tvMessage);

            tvMessage = ex.StackTrace;

#if _ENCRYPT_
            tvMessage = UTGHelper.Helper.EncryptString(tvMessage, "support");
#endif
            InputOutput.writeFileIfNotExistsAppending(currentDirectiory + ErrorHandler.ivErrorFileShortName, tvMessage);

            //NEW
            //ErrorHandler.HandleException(ex);
         }
         catch (Exception) { }

      }

      /// <summary>
      /// Alerts user of error condition. Gives user chance to report error. Logs exceptions.
      /// </summary>
      /// <param name="ex"></param>
      public static void HandleException(Exception ex)
      {
         ShowError(ex.Message, ex.Message);
      }

      private static void ShowError(string generalMessage, string details)
      {
         UserAlertBox txtUserAlert = new UserAlertBox(
                 generalMessage,
                 details,
                 UserAlertBox.UserAlertType.exception);

         txtUserAlert.Show();
      }

      /// <summary>
      /// Use to alert the user with a message. Will not log. Use HandleException on unexpected errors
      /// </summary>
      /// <param name="message"></param>
      /// <param name="emp"></param>
      public static void ShowMessage(string message)
      {
         UserAlertBox txtUserAlert = new UserAlertBox(
                 message,
                 UserAlertBox.UserAlertType.regularMessage);

         txtUserAlert.Show();
      }
   }
}
