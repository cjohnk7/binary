﻿

using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

using Extensibility;
using EnvDTE;
using EnvDTE80;

namespace UTGHelper
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   /// </summary>
   public static class Logger
   {
      public static void Trace(string message)
      {
         Console.WriteLine(message);
      }

      public static void ToStatusBar(EnvDTE.DTE applicationObject, string message)
      {
         applicationObject.StatusBar.Text = message;
      }

      public static string UPDATENOTIFYFILE = ".\\UpdateNotification.txt";

      public static void Write(string file, string content)
      {
         try
         {
            // create reader & open file
            TextWriter tr = new StreamWriter(file);

            tr.WriteLine(content);

            // close the stream
            tr.Close();

         }
         catch (Exception)
         {
         }
      }

      public static string Read(string file)
      {
         try
         {
            // create reader & open file
            TextReader tr = new StreamReader(file);

            string content = tr.ReadToEnd();

            // close the stream
            tr.Close();

            return content;
         }
         catch (Exception)
         {
            throw;
         }
      }
   }
}
