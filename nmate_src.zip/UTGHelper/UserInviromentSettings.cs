using System;
using System.Collections.Generic;
using System.Text;

namespace UTGHelper
{
   public static class UserInviromentSettings
   {
      public static int TAB = 3;
   }
}
