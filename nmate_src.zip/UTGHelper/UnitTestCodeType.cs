
using System;
using System.Collections.Generic;
using System.Text;

namespace UTGHelper
{
   public enum UnitTestCodeType
   {
      CSharp,
      VB
   }
}
