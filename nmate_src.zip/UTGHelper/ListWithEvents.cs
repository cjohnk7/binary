using System;
using System.Collections.Generic;
using System.Text;

namespace UTGHelper
{
   public class ListWithEvents<T> : List<T>
   {
      //public delegate void ListChangeDelegate();
      //public event ListChangeDelegate ListChangeEvent;

      //public ListWithEvents() : base() { }

      //protected void OnChange()
      //{
      //   //if (ListChangeEvent != null)
      //   //   ListChangeEvent();
      //}

      //new public void Add(T item)
      //{
      //   base.Add(item);

      //   OnChange();
      //}

      //new public void Insert(int index, T item)
      //{
      //   base.Insert(index, item);

      //   OnChange();
      //}

      //new public void Remove(T item)
      //{
      //   base.Remove(item);

      //   OnChange();
      //}

      //new public void Clear()
      //{
      //   base.Clear();

      //   OnChange();
      //}

      //new public void AddRange(IEnumerable<T> collection)
      //{
      //   base.AddRange(collection);

      //   OnChange();

      //}
   }
}
