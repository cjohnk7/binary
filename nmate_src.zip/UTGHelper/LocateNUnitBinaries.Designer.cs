﻿namespace UTGHelper
{
   partial class LocateNUnitBinaries
   {
      /// <summary> 
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary> 
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Component Designer generated code

      /// <summary> 
      /// Required method for Designer support - do not modify 
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.BrowserForNUnitBinariesDialog = new System.Windows.Forms.FolderBrowserDialog();
         this.btnOK = new System.Windows.Forms.Button();
         this.txtContent = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // btnOK
         // 
         this.btnOK.Location = new System.Drawing.Point(114, 140);
         this.btnOK.Name = "btnOK";
         this.btnOK.Size = new System.Drawing.Size(75, 23);
         this.btnOK.TabIndex = 0;
         this.btnOK.Text = "OK";
         this.btnOK.UseVisualStyleBackColor = true;
         this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
         // 
         // txtContent
         // 
         this.txtContent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                     | System.Windows.Forms.AnchorStyles.Left)
                     | System.Windows.Forms.AnchorStyles.Right)));
         this.txtContent.BackColor = System.Drawing.SystemColors.Control;
         this.txtContent.BorderStyle = System.Windows.Forms.BorderStyle.None;
         this.txtContent.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.txtContent.Location = new System.Drawing.Point(20, 33);
         this.txtContent.Margin = new System.Windows.Forms.Padding(20, 22, 20, 22);
         this.txtContent.Multiline = true;
         this.txtContent.Name = "txtContent";
         this.txtContent.RightToLeft = System.Windows.Forms.RightToLeft.No;
         this.txtContent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.txtContent.Size = new System.Drawing.Size(263, 92);
         this.txtContent.TabIndex = 4;
         // 
         // LocateNUnitBinaries
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.Controls.Add(this.txtContent);
         this.Controls.Add(this.btnOK);
         this.Name = "LocateNUnitBinaries";
         this.Size = new System.Drawing.Size(298, 176);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.FolderBrowserDialog BrowserForNUnitBinariesDialog;
      private System.Windows.Forms.Button btnOK;
      private System.Windows.Forms.TextBox txtContent;
   }
}
