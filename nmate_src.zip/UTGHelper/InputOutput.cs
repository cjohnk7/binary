﻿

using System;
using System.Collections.Generic;
using System.Text;

using System.IO;
using System.Security.Cryptography;

namespace UTGHelper
{
   /// <summary>
   /// This source is under the New BSD License
   /// Do not modify, distribute, or keep copies of this program for any reason unless you have read and understand the New BSD License.
   /// </summary>
   public static class InputOutput
   {
      public enum traceLevel
      {
         none,
         debug,
         verbose
      }

      public enum PathType
      {
         memeory,
         diskFile
      }

      public static string readMemeory(string memory)
      {
         return (string)memory.Clone();
      }

      public static string readFile(string file)
      {
         string content = "";

         StringBuilder fileContentBuilder = new StringBuilder();

         System.IO.FileStream fs = null;

         try
         {
            fs = System.IO.File.OpenRead(file);

            byte[] bytesArray = new byte[1000];

            int bytesRead = bytesRead = fs.Read(bytesArray, 0, 1000);


            while (bytesRead > 0)
            {

               for (int i = 0; i < bytesRead; i++)
               {
                  fileContentBuilder.Append((char)bytesArray[i]);
               }

               bytesRead = fs.Read(bytesArray, 0, 1000);
            }

            content = fileContentBuilder.ToString();
         }
         catch (Exception ex)
         {
            ErrorHandler.HandleException(ex);
         }
         finally
         {
            if (fs != null)
               fs.Close();
         }

         return content;
      }

      public static string writeFileIfNotExistsAppending(string file, string content)
      {
         StringBuilder fileContentBuilder = new StringBuilder();
         System.IO.FileStream fs = null;

         content = "\n\t" + content;

         try
         {
            fs = new System.IO.FileStream(file, FileMode.OpenOrCreate | System.IO.FileMode.Append);

            char[] chars = content.ToCharArray();
            byte[] bytes = new byte[chars.Length];

            for (int i = 0; i < chars.Length; i++)
            {
               fs.WriteByte((byte)chars[i]);
            }

            //fs.WriteByte(bytes, 0, bytes.Length);
         }
         catch (System.IO.IOException)
         {
            //do nothing
            //UTGHelper.ErrorHandler.HandleException(ex);
         }
         catch (Exception ex)
         {
            UTGHelper.ErrorHandler.HandleException(ex);
         }
         finally
         {
            if (fs != null)
               fs.Close();
         }

         return content;
      }

      public static string writeFileIfNotExists(string file, string content)
      {
         StringBuilder fileContentBuilder = new StringBuilder();
         System.IO.FileStream fs = null;

         try
         {
           fs = new System.IO.FileStream(file, System.IO.FileMode.OpenOrCreate);

            char[] chars = content.ToCharArray();
            byte[] bytes = new byte[chars.Length];

            for (int i = 0; i < chars.Length; i++)
            {
               bytes[i] = (byte)chars[i];
            }

            fs.Write(bytes, 0, bytes.Length);
         }
         catch (System.IO.IOException)
         {
            //do nothing
            //UTGHelper.ErrorHandler.HandleException(ex);
         }
         catch (Exception ex)
         {
            UTGHelper.ErrorHandler.HandleException(ex);
         }
         finally
         {
            if (fs != null)
               fs.Close();
         }

         return content;
      }

      public static string writeFile(string file, string content)
      {
         StringBuilder fileContentBuilder = new StringBuilder();
         System.IO.FileStream fs = null;

         try
         {
           fs = new System.IO.FileStream(file, System.IO.FileMode.CreateNew);

            char[] chars = content.ToCharArray();
            byte[] bytes = new byte[chars.Length];

            for (int i = 0; i < chars.Length; i++)
            {
               bytes[i] = (byte)chars[i];
            }

            fs.Write(bytes, 0, bytes.Length);
         }
         catch (Exception)
         {
            //UTGHelper.ErrorHandler.HandleException(ex);
         }
         finally
         {
            if (fs != null)
               fs.Close();
         }

         return content;
      }

      public static void consoleWriteLine(string message, traceLevel traceLevel)
      {

      }

      public static bool DirectoryExists(string directoryFullPath)
      {
         System.IO.DirectoryInfo drInfo = null;

         try
         {
            drInfo = new System.IO.DirectoryInfo(directoryFullPath);

            return drInfo.Exists;
         }

         catch (Exception ex)
         {
            UTGHelper.ErrorHandler.HandleException(ex);

            return false;
         }
      }

      public static bool DirectoryCreate(string directoryFullPath)
      {
         System.IO.DirectoryInfo drInfo = null;

         try
         {
            drInfo = System.IO.Directory.CreateDirectory(directoryFullPath);

            return drInfo.Exists;
         }
         catch (Exception ex)
         {
            UTGHelper.ErrorHandler.HandleException(ex);

            return false;
         }
      }
   }

   public static class FileInputOutput
   {
      static string NCLASS_UNIT_TEST_CSHARP_TEMPLATE_FILE =  System.Environment.CurrentDirectory + "\\CSharpFileTemplate.utt";
      
      static string NCLASS_UNIT_TEST_VB_TEMPLATE_FILE =  System.Environment.CurrentDirectory + "\\VisualBasicFileTemplate.utt";

      public static string GetCSharpUnitTestTemplateFileContent()
      {
         return GetNClassUnitTestTemplateFileContent(NCLASS_UNIT_TEST_CSHARP_TEMPLATE_FILE);
      }

      public static string GetVisualBasicUnitTestTemplateFileContent()
      {
         return GetNClassUnitTestTemplateFileContent(NCLASS_UNIT_TEST_VB_TEMPLATE_FILE);
      }

      private static string GetNClassUnitTestTemplateFileContent(string filePath)
      {
         string fileContent = string.Empty;

         try
         {
            fileContent = InputOutput.readFile(filePath);
            fileContent = fileContent.Trim();
            fileContent = fileContent.TrimStart();
            fileContent = fileContent.TrimEnd();
         }
         catch (Exception ex)
         {
            ErrorHandler.HandleException(ex);

            throw;
         }

         return fileContent;
      }



      public static string GetUnitTestProjectConfigurationFileContent()
      {

         return @"
<NUnitProject>
  <Settings activeconfig=""Debug"" />
  <Config name=""Debug"" binpathtype=""Auto"">
    <assembly path=""{0}"" />
  </Config>
  <Config name=""Release"" binpathtype=""Auto"" />
</NUnitProject>
";

         //string fileContent = string.Empty;

         //try
         //{
         //   fileContent = InputOutput.readFile(UNIT_TEST_PROJECT_CONFIGURATION_XML_TEMPLATE_FILE);
         //   fileContent = fileContent.Trim();
         //   fileContent = fileContent.TrimStart();
         //   fileContent = fileContent.TrimEnd();
         //}
         //catch (Exception ex)
         //{
         //   ErrorHandler.HandleException(ex);

         //   throw;
         //}

         //return fileContent;
      }

      /// <summary>
      /// New
      /// </summary>
      /// <param name="fileFullName"></param>
      /// <returns></returns>
      public static string GetFilePath(string fileFullName)
      {
         if (fileFullName.Equals(string.Empty))
            throw new Exception("Invalid Parameter fileFullName!");

         System.IO.DirectoryInfo directoryInfo = null;

         directoryInfo = new System.IO.DirectoryInfo(fileFullName);

         //This will include the solution name as well! There has to be a better call.. 
         //remove the solution name for time being
         int parentDirectory =
            directoryInfo.FullName.LastIndexOf('\\');

         string path = directoryInfo.FullName.Substring(0, parentDirectory);

         return path;
      }
   }
   
   public static class Helper
   {
      private static readonly byte[] SALT = new byte[] { 0x26, 0xdc, 0xff, 0x00, 0xad, 0xed, 0x7a, 0xee, 0xc5, 0xfe, 0x07, 0xaf, 0x4d, 0x08, 0x22, 0x3c };
 
      public static byte[] Encrypt(byte[] plain, string password)
      {
         MemoryStream memoryStream;
         CryptoStream cryptoStream;
         Rijndael rijndael = Rijndael.Create();
         Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(password, SALT);
         rijndael.Key = pdb.GetBytes(32);
         rijndael.IV = pdb.GetBytes(16);
         memoryStream = new MemoryStream();
         cryptoStream = new CryptoStream(memoryStream, rijndael.CreateEncryptor(), CryptoStreamMode.Write);
         cryptoStream.Write(plain, 0, plain.Length);
         cryptoStream.Close();
         return memoryStream.ToArray();
      }

      public static byte[] Decrypt(byte[] cipher, string password)
      {
         MemoryStream memoryStream;
         CryptoStream cryptoStream;
         Rijndael rijndael = Rijndael.Create();
         Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(password, SALT);
         rijndael.Key = pdb.GetBytes(32);
         rijndael.IV = pdb.GetBytes(16);
         memoryStream = new MemoryStream();
         cryptoStream = new CryptoStream(memoryStream, rijndael.CreateDecryptor(), CryptoStreamMode.Write);
         cryptoStream.Write(cipher, 0, cipher.Length);
         cryptoStream.Close();
         return memoryStream.ToArray();
      }

      public static string EncryptString(string InputText, string Password)
      {
         RijndaelManaged RijndaelCipher = new RijndaelManaged();

         byte[] PlainText = System.Text.Encoding.Unicode.GetBytes(InputText);

         byte[] Salt = Encoding.ASCII.GetBytes(Password.Length.ToString());

         PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(Password, Salt);

         ICryptoTransform Encryptor = RijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));

         MemoryStream memoryStream = new MemoryStream();

         CryptoStream cryptoStream = new CryptoStream(memoryStream, Encryptor, CryptoStreamMode.Write);

         cryptoStream.Write(PlainText, 0, PlainText.Length);

         cryptoStream.FlushFinalBlock();

         byte[] CipherBytes = memoryStream.ToArray();

         memoryStream.Close();

         cryptoStream.Close();

         string EncryptedData = Convert.ToBase64String(CipherBytes);

         // Return encrypted string.
         return EncryptedData;
      }

      public static string DecryptString(string InputText, string Password)
      {
         RijndaelManaged RijndaelCipher = new RijndaelManaged();

         byte[] EncryptedData = Convert.FromBase64String(InputText);

         byte[] Salt = Encoding.ASCII.GetBytes(Password.Length.ToString());

         PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(Password, Salt);

         ICryptoTransform Decryptor = RijndaelCipher.CreateDecryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));

         MemoryStream memoryStream = new MemoryStream(EncryptedData);

         CryptoStream cryptoStream = new CryptoStream(memoryStream, Decryptor, CryptoStreamMode.Read);

         byte[] PlainText = new byte[EncryptedData.Length];

         int DecryptedCount = cryptoStream.Read(PlainText, 0, PlainText.Length);

         memoryStream.Close();

         cryptoStream.Close();

         string DecryptedData = Encoding.Unicode.GetString(PlainText, 0, DecryptedCount);

         return DecryptedData;

      }
   }
}
